



import 'package:cursos_app/models/curso_model.dart';

class CursoRepository{
  List<CursoModel> findAll() {
    
    return <CursoModel>[
    CursoModel(
      id: 1,
      nome: 'Java',
      nivel:'Básico',
      percentualConclusao:1,
      preco:100.0),
    CursoModel(
      id: 2,
      nome: 'J2EE',
      nivel: 'Avançado',
      percentualConclusao: 0.7,
      preco: 100.0),
    CursoModel(
      id: 3,
      nome: 'J2EE',
      nivel: 'Avançado',
      percentualConclusao:  0.8,
      preco: 100.0),
  ];
}
}

