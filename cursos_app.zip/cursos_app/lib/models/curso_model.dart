import 'package:flutter/material.dart';

class CursoModel {
  int id;
  String nome;
  String nivel;
  double percentualConclusao;
  double preco;
  String conteudo;

  CursoModel({required this.id, 
  required this.nome,
  required this.nivel,
  required this.percentualConclusao, 
  required this.preco, 
  this.conteudo = ''});

}

  

//nul safety