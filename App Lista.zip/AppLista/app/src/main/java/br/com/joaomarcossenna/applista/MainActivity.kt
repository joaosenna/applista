package br.com.joaomarcossenna.applista

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.DividerItemDecoration

class MainActivity : AppCompatActivity() {
    var churras: MutableList<Churras> = mutableListOf<Churras>(
        Churras(R.drawable.carvao, "Carvão Vegetal", "8Kg", "R$ 37,00"),
        Churras(R.drawable.drumet_de_frango, "Coxinha de Frango", "1Kg", "R$ 20,00"),
        Churras(R.drawable.fraldinha, "Fraldinha", "1,5 kg", "R$ 48,00"),
        Churras(R.drawable.picanha, "Picanha maturada", "2kg", "R$ 130,00"),
        Churras(R.drawable.linguica_toscana, "Linguiça toscana", "1,5 kg", "R$ 30,00"),
        Churras(R.drawable.pao_de_alho, "Pão de alho", "800g", "R$ 18,00"))

            override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = ChurrasAdapter(churras)

            val itemDecor = DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
            recyclerView.addItemDecoration(itemDecor)
        }
}
