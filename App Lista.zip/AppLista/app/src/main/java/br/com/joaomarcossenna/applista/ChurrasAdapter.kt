package br.com.joaomarcossenna.applista

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChurrasAdapter (private val dataSet: List<Churras>): RecyclerView.Adapter<ChurrasAdapter.ViewHolder>(){

    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        val imageViewProduto: ImageView
        val textViewDescricao: TextView
        val textViewQtd: TextView
        val textViewPreco: TextView

        init {
            imageViewProduto = view.findViewById(R.id.imageViewProduto)
            textViewDescricao = view.findViewById(R.id.textViewDescricao)
            textViewQtd = view.findViewById(R.id.textViewQtd)
            textViewPreco = view.findViewById(R.id.textViewPreco)

        }
    }

    //Define o layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recyclerview_churras, parent, false)

        return ViewHolder(view)
    }

    //De/Para Objeto para o layout
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val churras = dataSet[position]
        holder.imageViewProduto.setImageResource(churras.image)
        holder.textViewDescricao.text = churras.descricao
        holder.textViewQtd.text = churras.qtd
        holder.textViewPreco.text = churras.preco

    }

    //Retorna o tamanho da lista
    override fun getItemCount(): Int {
        return dataSet.size
    }
}