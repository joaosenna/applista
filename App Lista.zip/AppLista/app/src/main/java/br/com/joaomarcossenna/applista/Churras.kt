package br.com.joaomarcossenna.applista

data class Churras(val image: Int, val descricao: String, val qtd: String, val preco: String)